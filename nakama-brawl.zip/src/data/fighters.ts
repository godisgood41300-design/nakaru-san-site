export type Fighter = {
  id: string; name: string; archetype: string; lore: string; color: string;
  stats: { power: number; speed: number; defense: number; energy: number };
  moves: { basic: string; special: string; ultimate: string };
};
export const fighters: Fighter[] = [
  {id:'ryo',name:'Ryo Stormhand',archetype:'Storm Brawler',color:'from-orange-500 to-sky-500',lore:'A restless hero who channels storm aura through fearless close-range attacks.',stats:{power:7,speed:8,defense:5,energy:7},moves:{basic:'Gale Jab',special:'Storm Clone Rush',ultimate:'Spiral Tempest Palm'}},
  {id:'kael',name:'Kael Moonblade',archetype:'Spirit Swordsman',color:'from-slate-200 to-indigo-600',lore:'A calm blade master whose moonlit sword pressure cuts through darkness.',stats:{power:8,speed:6,defense:7,energy:8},moves:{basic:'Moon Cut',special:'Crescent Flash',ultimate:'Silent Eclipse Divide'}},
  {id:'juno',name:'Juno Tidefist',archetype:'Freedom Fighter',color:'from-red-500 to-blue-500',lore:'A wild adventurer whose elastic martial arts hit like crashing waves.',stats:{power:8,speed:7,defense:6,energy:6},moves:{basic:'Tide Jab',special:'Ocean-Reach Hook',ultimate:'Freedom Rush Barrage'}},
  {id:'amari',name:'Amari Flameborn',archetype:'Phoenix Striker',color:'from-red-600 to-yellow-400',lore:'A fire-hearted champion who turns pain into phoenix flame.',stats:{power:9,speed:6,defense:5,energy:8},moves:{basic:'Ember Fist',special:'Flame Dash',ultimate:'Phoenix Burst'}},
  {id:'sora',name:'Sora Ironpulse',archetype:'Tech Martial Artist',color:'from-cyan-400 to-zinc-700',lore:'A hoodie-armored fighter using magnetic footwork and glowing gauntlets.',stats:{power:7,speed:6,defense:8,energy:7},moves:{basic:'Mag Jab',special:'Gravity Step',ultimate:'Iron Pulse Cannon'}},
  {id:'nyx',name:'Nyx Shadowveil',archetype:'Shadow Duelist',color:'from-purple-700 to-black',lore:'A fast veil-dancer who fights with eclipse energy and shadow blades.',stats:{power:6,speed:10,defense:4,energy:9},moves:{basic:'Veil Slash',special:'Shadow Dash',ultimate:'Eclipse Field'}},
];
