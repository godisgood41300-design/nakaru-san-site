import React from 'react';
export function MobileControls({act}:{act:(a:string)=>void}){return <div className="grid grid-cols-4 gap-2 mt-4 md:hidden">{['Left','Right','Jump','Dash','Block','Attack','Special','Ultimate'].map(x=><button key={x} onClick={()=>act(x.toLowerCase())} className="bg-white/10 rounded-xl p-3 text-xs font-bold">{x}</button>)}</div>}
