import React from 'react';
export function Navbar({page,setPage}:{page:string;setPage:(p:string)=>void}){
 const items=['Home','Select','Roster','Training','Profile','Settings'];
 return <nav className="sticky top-0 z-10 backdrop-blur bg-black/50 border-b border-white/10 p-3 flex gap-2 overflow-x-auto">
  <b className="mr-3 text-yellow-300">Nakama Brawl</b>{items.map(i=><button key={i} onClick={()=>setPage(i)} className={`px-3 py-2 rounded-xl ${page===i?'bg-yellow-400 text-black':'bg-white/10'}`}>{i}</button>)}
 </nav>
}
